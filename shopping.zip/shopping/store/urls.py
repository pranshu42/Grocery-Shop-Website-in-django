from django.contrib import admin
from django.urls import path
from store import views



urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.HomePage,name='homepage'),
    path('singup',views.singup,name='singup'),
    path('login',views.login,name='login'),
    path('product-detail/<int:pk>',views.productdetail,name='product-detail'),
    path('logout',views.logout,name='logout'),
    path('add-to-cart',views.add_to_cart,name='add-to-cart'),
    path('show-cart',views.showcart,name='show-cart'),
    path('plus_cart',views.pluse_cart,name='plus_cart'),
    path('minus_cart',views.minus_cart,name='minus_cart'),
    path('remove_cart',views.remove_cart,name='remove_cart'),
    path('checkout',views.checkout,name='checkout'),
    path('order',views.oorder,name='order'),
    path('search',views.search,name='search'),
    

]

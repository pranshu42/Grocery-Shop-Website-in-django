from django.contrib import admin

# Register your models here.

from .models.product import Product

from .models.category import Category
from .models.customer import Customer
from .models.cart import Cart
from .models.order import OrderDetail

class AdninProduct(admin.ModelAdmin):
    list_display = ['id','name','price','category','descripition']

class AdninCustomer(admin.ModelAdmin):
    list_display = ['id','name','phone']


class AdninCart(admin.ModelAdmin):
    list_display = ['id','phone','product','image','price']


class AdninOrder(admin.ModelAdmin):
    list_display = ['id','user','product_name','image','qty','price','staus','ordered_date']    




admin.site.register(Product,AdninProduct)
admin.site.register(Category)
admin.site.register(Customer,AdninCustomer)
admin.site.register(Cart,AdninCart)
admin.site.register(OrderDetail,AdninOrder)


